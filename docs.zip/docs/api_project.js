define({
  "title": "eMovie-system",
  "description": "eMovie-system API 文档",
  "url": "",
  "template": {
    "withCompare": true,
    "withGenerator": true
  },
  "name": "eMovie-system",
  "version": "0.0.0",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-06-08T13:13:39.695Z",
    "url": "http://apidocjs.com",
    "version": "0.17.5"
  }
});
